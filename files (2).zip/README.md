# Holio Ops – Eskeforslag

Bidrag til **Holio Challenge** på Oslo Sprint (6.–8. november 2026), pain 5: *Feil eske*.

Når en pakker velger eske på øyemål, blir den ofte én størrelse for stor. Da betaler nettbutikken for luft, fyllmateriale og høyere volumvekt på hver eneste pakke. Eskeforslag finner esken som gir lavest totalpris for ordren, deler ordren i flere kolli når den ikke får plass, og viser pakkeren steg for steg hvor hver vare skal ligge.

## Funksjoner

- **Eskeforslag i 3D.** Prøver alle eskestørrelsene med en 3D-pakkealgoritme og velger den med lavest totalpris, ikke bare den minste. Resultatet vises i en roterbar 3D-modell.
- **Deling i flere kolli.** Når ingen eske rommer hele ordren, deles den automatisk. Hvert kolli teller som en egen forsendelse, så ordren deles bare når det er nødvendig.
- **Skannermodus.** En simulert Zebra TC27 med Holio Ops-skjerm. Pakkeren skanner esken (feil eske blir stoppet), skanner varene én etter én mens en gul ramme i 3D viser hvor hver vare skal ligge, og sender etiketten til Skyprint.
- **CSV-import.** Lim inn eller dra inn en CSV med mange ordrer. Appen analyserer alle og viser anbefalt eske per ordre og samlet besparelse.
- **Åpen besparelsesberegning.** Regnestykket vises på siden og kan justeres.
- Lys og mørk modus, og fungerer på mobil.

## Kom i gang

Appen er én enkelt HTML-fil uten byggesteg.

- **Lokalt:** Åpne `index.html` i nettleseren.
- **GitHub Pages:** Gå til *Settings → Pages*, velg branchen `main` og mappen `/ (root)`. Siden publiseres på `https://<brukernavn>.github.io/<repo>/`.

Nettleseren trenger internett for å laste three.js (fra cdnjs) og fonten Figtree (fra Google Fonts).

## CSV-format

Én linje per vare. Både semikolon og komma fungerer som skilletegn, og desimaler kan skrives med komma.

```csv
ordre;vare;lengde;bredde;høyde;vekt;antall
20481;Ullsokker 2-pk;18;12;4;0,15;3
20481;Lue;22;18;5;0,12;1
20482;Kokebok;26;20;3;1,1;1
```

Mål er i cm og vekt i kg. Kolonnen `ordre` og `antall` kan utelates. Engelske kolonnenavn (`order`, `name`, `length`, `width`, `height`, `weight`, `qty`) fungerer også.

## Slik regnes det

**Pris for en eske** = frakt + eskekostnad + fyllmateriale + forsendelsesgebyr

- **Volumvekt** = ytre mål (cm³) ÷ 5000
- **Fraktvekt** = den største av faktisk vekt og volumvekt, og fraktprisen slås opp i en vekttabell
- **Fyllmateriale** = tomrom i liter × 0,15 kr
- **Forsendelsesgebyr** = 2,90 kr per kolli

**Besparelse per år** = (pris med én størrelse for stor − pris med riktig eske) × pakker per dag × andel pakker med for stor eske i dag × 250 dager

> **Merk:** Fraktpriser, eskestørrelser og eskekostnader er eksempeltall. For ekte tall må modellen kobles til prisene i transportøravtalen.

## Pakkealgoritmen

Appen bruker en «extreme point»-heuristikk:

1. Varene sorteres etter volum, største først.
2. Hver vare prøves i alle seks rotasjoner på alle ledige hjørnepunkter.
3. Plasseringen som holder pakken lavest vinner. En vare må ha minst 60 % støtte under seg.

Algoritmen er rask nok til å kjøre i sanntid og foreslår aldri en eske som er for liten. Den er ikke garantert optimal, så den kan av og til velge en litt større eske enn strengt nødvendig.

## Videre arbeid

- Koble til ekte fraktpriser fra Profrakt-avtalen og sammenligne transportører (Bring, PostNord, Helthjem og andre)
- Hente varemål automatisk fra nettbutikken eller WMS, eller måle med kamera (pain 1)
- Lese ordre direkte fra Holio i stedet for CSV

## Teknologi

- Ren HTML, CSS og JavaScript
- [three.js](https://threejs.org/) r128 for 3D
- Fonten [Figtree](https://fonts.google.com/specimen/Figtree)

All testdata er oppdiktet. Appen bruker ingen ekte kundedata.
